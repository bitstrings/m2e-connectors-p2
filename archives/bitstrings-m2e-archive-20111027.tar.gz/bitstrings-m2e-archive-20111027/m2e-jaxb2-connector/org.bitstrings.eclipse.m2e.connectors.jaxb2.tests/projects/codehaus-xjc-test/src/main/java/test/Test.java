package test;

import generated.Items;

public class Test
{
    public Test()
    {
        Items items = new Items();
    }
}
