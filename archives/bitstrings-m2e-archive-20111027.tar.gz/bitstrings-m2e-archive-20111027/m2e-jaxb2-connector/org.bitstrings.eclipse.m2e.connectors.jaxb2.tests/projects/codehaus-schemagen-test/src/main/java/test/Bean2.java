package test;

public class Bean2
{
    private String prop3;

    public String getProp3()
    {
        return prop3;
    }

    public void setProp3(String prop3)
    {
        this.prop3 = prop3;
    }
}
