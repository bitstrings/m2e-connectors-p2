package test;

import noNamespace.Items;

public class Test
{
    public Test()
    {
        Items items = Items.Factory.newInstance();
    }
}
